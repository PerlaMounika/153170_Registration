package com.cg.sample;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ProjectPage {
@FindBy(how=How.ID,using="projectname")
	 WebElement top1;
@FindBy(how=How.ID,using="clientname")
WebElement top2;
@FindBy(how=How.ID,using="teamsize")
WebElement top3;
@FindBy(name="register")
WebElement register;
}



