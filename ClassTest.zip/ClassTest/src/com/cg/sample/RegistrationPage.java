package com.cg.sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {
	
		
        
        @FindBy(how=How.ID,using="firstname")
      	 WebElement pass;
      @FindBy(how=How.ID,using="lastname")
      WebElement pass2;

      @FindBy(how=How.ID,using="Email Id")
      WebElement pass3;
      @FindBy(how=How.ID,using="Gender")
      WebElement pass4;

      @FindBy(how=How.ID,using="Mobile number")
      WebElement pass5;

      @FindBy(how=How.ID,using="address")
      WebElement pass6;
      @FindBy(how=How.ID,using="state")
      WebElement pass7;
      @FindBy(how=How.ID,using="city")
      WebElement pass8;
      @FindBy(name="submit")
      WebElement pass9;
      
         
       
        }


