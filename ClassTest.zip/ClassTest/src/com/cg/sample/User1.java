package com.cg.sample;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class User1 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("D:\\java work space _ core java\\ClassTest\\WebContent\\WEB-INF\\Registration.html");
		RegistrationPage details = PageFactory.initElements(driver, RegistrationPage.class);
		details.pass.sendKeys("Mounika");
		Thread.sleep(500);
		details.pass2.sendKeys("Perla");
		Thread.sleep(500);
        details.pass3.sendKeys("mounikaperla.b@gmail.com");
        Thread.sleep(300);
        Select state=new Select(driver.findElement(By.id("state")));
        state.selectByIndex(2);
        Select gender=new Select(driver.findElement(By.id("gender")));
        state.selectByIndex(1);
		details.pass5.sendKeys("9666950866");
		details.pass6.sendKeys("agenda");
		details.pass8.sendKeys("hyderabad");
		details.pass9.click();
		Thread.sleep(500);
		driver.get("D:\\java work space _ core java\\ClassTest\\WebContent\\WEB-INF\\ProjectDetails.html");
		ProjectPage page = PageFactory.initElements(driver, ProjectPage.class);
		page.top1.sendKeys("java");
		page.top2.sendKeys("hindu");
		page.top3.sendKeys("six");
		page.register.click();
		Thread.sleep(1000);
		driver.get("D:\\java work space _ core java\\ClassTest\\WebContent\\WEB-INF\\SuccessPage.html");

	}
}
